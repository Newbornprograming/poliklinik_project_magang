<?php 
$databaseHost = 'localhost';
$databaseUsername = 'root';
$databasePassword = '';
$databaseName = 'poliklinik';

    $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);